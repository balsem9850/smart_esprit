#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include"tree.h"
#include"CRUD.h"
GtkTreeSelection *selection1;

void
on_AcceuilGestionw_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
/////////////////////////////////////*preparation du treeView*/////////////////////////////////////////
GtkWidget *p;
gtk_widget_hide (acceuilw);
gestionw = create_gestionw ();
p=lookup_widget(gestionw,"treeview2w");
Affichermenu(p,"menu.txt");
gtk_widget_show (gestionw);
}


void
on_Ajoutermenu_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
 menu t;
GtkWidget *entrytempsw;
GtkWidget *entryIdw;

GtkWidget *entryDatew;
GtkWidget *entryentreew;
GtkWidget *labelIdw;
GtkWidget *labeltempsw;

GtkWidget *labelDatew;
GtkWidget *labelentreew;
GtkWidget *existew;
GtkWidget* successw;
GtkWidget *calw;
GtkWidget *entrymenu;
GtkWidget *labelmenu;
GtkWidget *entrydessert;
GtkWidget *input7,*input8,*input9;
int b=1;
int jj1,mm1,aa1;
char date[50];
FILE*f=NULL;


entryIdw=lookup_widget(gestionw,"entry5w");
entrytempsw=lookup_widget(gestionw,"combobox1w");

entrymenu=lookup_widget(gestionw,"entrymenu");
entrydessert=lookup_widget(gestionw,"entrydessert");




input7=lookup_widget(button,"spinbuttonjour"); 
input8=lookup_widget(button,"spinbuttonmois");
input9=lookup_widget(button,"spinbuttonannee");


entryentreew=lookup_widget(gestionw,"entry3w");

labelIdw=lookup_widget(gestionw,"label13w");
labeltempsw=lookup_widget(gestionw,"label7w");



labelmenu=lookup_widget(gestionw,"labellabel");


labelentreew=lookup_widget(gestionw,"label10w");
existew=lookup_widget(gestionw,"label34w");
successw=lookup_widget(gestionw,"label35w");
//calw=lookup_widget(gestionw,"yawmia");
        strcpy(t.jour,gtk_entry_get_text(GTK_ENTRY(entryIdw) ) );
        strcpy(t.temps,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrytempsw)));
        

        strcpy(t.entree,gtk_entry_get_text(GTK_ENTRY(entryentreew) ) );
        strcpy(t.menu_principal,gtk_entry_get_text(GTK_ENTRY(entrymenu) ) );
	strcpy(t.dessert,gtk_entry_get_text(GTK_ENTRY(entrydessert) ) );
	




 gtk_widget_hide (successw);

 ///////////////////////////////////////////////////gtk_calendar_get_date (GTK_CALENDAR(calw)////////////////////////////////////////
                       &aa1,
                       &mm1,
                       &jj1;



        t.date1.jour  = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input7));
	t.date1.mois  = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input8));
	t.date1.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input9)); 
	//sscanf (t.date,"%d/%d/%d",&t.date1.jour,&t.date1.mois,&t.date1.annee);
        //sprintf (t.date,"%d/%d/%d",&t.date1.jour,&t.date1.mois,&t.date1.annee);
 gtk_widget_hide (successw);


// controle saisie////
if(strcmp(t.jour,"")==0){
		  gtk_widget_show (labelIdw);
b=0;
}
else {
		  gtk_widget_hide(labelIdw);
}

if(strcmp(t.temps,"")==0){
		  gtk_widget_show (labeltempsw);
b=0;
}
else {
		  gtk_widget_hide(labeltempsw);
}


if(strcmp(t.entree,"")==0){
		  gtk_widget_show (labelentreew);
b=0;
}
else {
		  gtk_widget_hide(labelentreew);
}

if(strcmp(t.menu_principal,"")==0){
		  gtk_widget_show (labelmenu);
b=0;
}
else {
		  gtk_widget_hide(labelmenu);
}


if(b==1){

        if(exist_menu(t.jour)==1)
        {

				  gtk_widget_show (existew);
                }
                else {
                     gtk_widget_hide (existew);

       f=fopen("menu.txt","a+");

fprintf(f,"%s %s %d/%d/%d %s %s %s \n",t.jour,t.temps,t.date1.jour,t.date1.mois,t.date1.annee,t.entree,t.menu_principal,t.dessert);
fclose(f);
     
////////ajouter_menu(t);
                  gtk_widget_show (successw);


////////mise a jour du treeView
      GtkWidget* p=lookup_widget(gestionw,"treeview2w");

        Affichermenu(p,"menu.txt");
}

}
}



void
on_Modifiermenu_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
      GtkWidget *combobox3w;
        GtkWidget *combobox4w;
     combobox3w=lookup_widget(button,"combobox3w");
     combobox4w=lookup_widget(button,"combobox4w");
       	 menu t;

        strcpy(t.jour,gtk_label_get_text(GTK_LABEL(lookup_widget(gestionw,"label20w"))));
        strcpy(t.temps,gtk_combo_box_get_active_text(GTK_COMBO_BOX(lookup_widget(gestionw,"combobox3w"))));
        
        strcpy(t.entree,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestionw,"entry8w"))));
        strcpy(t.date,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestionw,"entry9w"))));
	strcpy(t.menu_principal,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestionw,"entryrec"))));
	strcpy(t.dessert,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestionw,"entrydes"))));
	


        supprimer_menu(t.jour);
        ajouter_menu(t);
////////mise ajour du tree view 
        Affichermenu(lookup_widget(gestionw,"treeview1"),"menu.txt");
	gtk_widget_show(lookup_widget(gestionw,"label37w"));
        GtkWidget *p=lookup_widget(gestionw,"treeview2w");
        Affichermenu(p,"menu.txt");
}





void
on_cherchermenu_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *p1w;
GtkWidget *entryw;
GtkWidget *labelidw;
GtkWidget *nbResultatw;
GtkWidget *messagew;
char jour[30];
char chnb[30];
int b=0,nb; //b=0  entry  cherche vide 
entryw=lookup_widget(gestionw,"entry10w");
labelidw=lookup_widget(gestionw,"label28w");
p1w=lookup_widget(gestionw,"treeview2w");
strcpy(jour,gtk_entry_get_text(GTK_ENTRY(entryw)));

if(strcmp(jour,"")==0){
  gtk_widget_show (labelidw);b=0;
}else{
b=1;
gtk_widget_hide (labelidw);}

if(b==0)
    {return;
    }
    else
    {

nb=Cherchermenu(p1w,"menu.txt",jour);
////// afficher le tempsbre de resultats obtenue par la recherche
 

sprintf(chnb,"%d",nb);       // //conversion int==> chaine car la fonction gtk_label_set_text naccepte que chaine
nbResultatw=lookup_widget(gestionw,"label27");
messagew=lookup_widget(gestionw,"label26w");
gtk_label_set_text(GTK_LABEL(nbResultatw),chnb);

gtk_widget_show (nbResultatw);
gtk_widget_show (messagew);
}
}


void
on_GestionAcceuilw_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (acceuilw);
gtk_widget_destroy (gestionw);

}




void
on_bmodifier_clickedw                   (GtkButton       *button,
                                        gpointer         user_data)
{
        gchar *jour;
        gchar *temps;
        gchar *date;
        gchar *entree;
	gchar *menu_principal;
	gchar *dessert;
	
  
        GtkTreeModel     *model;
        GtkTreeIter iter;
        if (gtk_tree_selection_get_selected(selection1, &model, &iter))
        {

        gtk_widget_hide(lookup_widget(gestionw,"label37w"));
////cacher label modifier avec succees
                gtk_tree_model_get (model,&iter,0,&jour,1,&temps,2,&date,3,&entree,4,&menu_principal,5,&dessert,-1);
////////recuperer les information de la ligne selectionneé



        //// //remplir les champs de entry
               
   
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestionw,"entry9w")),date);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestionw,"entry8w")),entree);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestionw,"entryrec")),menu_principal);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestionw,"entrydes")),dessert);
 

                GtkWidget* msgId=lookup_widget(gestionw,"label20w");
                GtkWidget* msg1=lookup_widget(gestionw,"label36w");
                gtk_label_set_text(GTK_LABEL(msgId),jour);
                gtk_widget_show(msgId);
                gtk_widget_show(msg1);
                gtk_widget_show(lookup_widget(gestionw,"button4w"));//afficher le bouton modifier
                gtk_notebook_prev_page(GTK_NOTEBOOK(lookup_widget(gestionw,"notebook1w")));//redirection vers la page precedente
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestionw,"entry9w")),date);
                
             
        }

}


void
on_bsupprimer_clickedw                  (GtkButton       *button,
                                        gpointer         user_data)
{
    gchar *jour;
    gchar *temps;
    
    gchar *date;
    gchar *entree;
    gchar *menu_principal;
    gchar *dessert;
    GtkTreeModel     *model;
    GtkTreeIter iter;
       if (gtk_tree_selection_get_selected(selection1, &model, &iter))
        {
            gtk_tree_model_get (model,&iter,0,&jour,1,&temps,2,&date,3,&entree,4,&menu_principal,5,&dessert,6,-1);//recuperer les information de la ligne selectionneé
            supprimer_menu(jour);
            Affichermenu(lookup_widget(gestionw,"treeview2w"),"menu.txt");        
        }
}


void
on_bafficher12w_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
        GtkWidget *p=lookup_widget(gestionw,"treeview2w");
        Affichermenu(p,"menu.txt");
}


void
on_treeview2w_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)//signale du treeView (Double click)
{
    	gchar *jour;
        gchar *temps;
        
        gchar *date;
        gchar *entree;
	gchar *menu_principal;
        gchar *dessert;
	GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget *p=lookup_widget(gestionw,"treeview2w");
        selection1 = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
       
}





