

void Affichermenu(GtkWidget* treeview1,char*l);
int Cherchermenu(GtkWidget* treeview1,char*l,char*jour);

